using UnityEngine;
using System.Collections;
using UnityEditor;

public class ApplyTerrainShader : AssetPostprocessor 
{
	
   	static void OnPostprocessAllAssets(string[] importedAssets, string[] deletedAssets, string[] movedAssets, string[] movedFromPath)
   	{
        foreach (string i in importedAssets)
        {
			//Debug.Log("[ApplyTerrainShader] Imported Asset: " + i);
			//return;
			if( i.Contains(".mat") && i.Contains("terrainzone") )
			{
				//Debug.Log("[ApplyTerrainShader] Is material");
				Material mat = (Material)AssetDatabase.LoadAssetAtPath(i, typeof(Material));
				if(mat)
				{
					//Debug.Log("[ApplyTerrainShader] Change shader");
					mat.shader = Shader.Find("Custom/TerrainShader");
					
					// Set the detail texture.
					Texture detail_tex = (Texture)AssetDatabase.LoadAssetAtPath("Assets/STKZone1_Desert/MountainCircuit/Textures/gravel05.png", typeof(Texture));
					
					if(detail_tex)
					{
						mat.SetTexture("_DetailTex1", detail_tex);
						//Debug.Log("[ApplyTerrainShader] Apply detail textures");
					}
					
					Vector2 scale;
					scale.x = 80f;
					scale.y = 80f;
					mat.SetTextureScale("_DetailTex1", scale);
					Color cl = new Color( 1.0f, 1.0f, 1.0f, 1.0f );
					mat.SetColor( "Main Color", cl );
				}
			}
        }
		//Debug.Log( "Detail texture assigned" );
   	}	
}
